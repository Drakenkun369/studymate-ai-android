# StudyMate AI — Android starter project

A dark black-and-purple Android study assistant starter built with Kotlin and Jetpack Compose.

## Current features
- Home dashboard
- Navigation between Home, Tutor, Practice, Notes and Profile
- Tutor chat interface (placeholder; not connected to a live AI model yet)
- Three-question sample quiz with answer feedback
- Sample subject revision notes
- Profile/preferences placeholder

## Requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK Platform 35
- Android phone with Android 7.0 (API 24) or newer, or an emulator

## Open the project
1. Extract the ZIP file.
2. Open Android Studio.
3. Choose **Open** and select the `StudyMateAI` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle to sync and install any requested Android SDK components.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run**.

If Android Studio asks to update Gradle or Android Gradle Plugin, do not accept a major upgrade automatically; first check compatibility.

## Important: live AI is not connected yet
The Tutor screen currently demonstrates the interface and displays a local placeholder response. It does not call an AI service.

The next implementation stage is a secure backend:
- Android app sends a question to our backend.
- Backend stores the AI provider credential in server-side environment configuration.
- Backend calls the selected AI provider and returns the response.
- Never embed a private API key in the Android app or commit one to source control.

No API key is included in this project.

## Planned next stages
1. Secure AI backend and real tutor responses.
2. Student profile: class, board, subjects and exam goal.
3. AI-generated quizzes with answer explanations.
4. Notes creation, editing and local/cloud saving.
5. Image question input and OCR/vision support.
6. Progress tracking, privacy controls and release testing.

## Project identity
- App name: StudyMate AI
- Package: `com.studymateai.app`
- Design: dark background with purple accents
- Intended audience: Classes 9–12 and JEE, NEET and CET learners

## Notes
This is a starter build, not a production-ready release. AI-generated educational content must be checked for accuracy. Before public release, add appropriate privacy disclosures, data deletion controls, secure authentication/rate limits where needed, and test on supported devices.
