package com.studymateai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0D0B14)
private val Surface = Color(0xFF191526)
private val Surface2 = Color(0xFF211B32)
private val Purple = Color(0xFF9B6DFF)
private val Lavender = Color(0xFFC8B4FF)
private val Muted = Color(0xFFAAA2B9)
private val White = Color(0xFFF8F5FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyMateApp() }
    }
}

private enum class Tab(val label: String) {
    HOME("Home"), TUTOR("Tutor"), PRACTICE("Practice"), NOTES("Notes"), PROFILE("Profile")
}

@Composable
private fun StudyMateApp() {
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            secondary = Lavender,
            background = Bg,
            surface = Surface,
            onBackground = White,
            onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Surface, contentColor = White) {
                    Tab.entries.forEach { tab ->
                        val icon = when (tab) {
                            Tab.HOME -> Icons.Default.Home
                            Tab.TUTOR -> Icons.Default.AutoAwesome
                            Tab.PRACTICE -> Icons.Default.Quiz
                            Tab.NOTES -> Icons.Default.Description
                            Tab.PROFILE -> Icons.Default.Person
                        }
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Lavender,
                                selectedTextColor = Lavender,
                                indicatorColor = Color(0xFF39285B),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selectedTab) {
                    Tab.HOME -> HomeScreen(
                        onTutor = { selectedTab = Tab.TUTOR },
                        onPractice = { selectedTab = Tab.PRACTICE },
                        onNotes = { selectedTab = Tab.NOTES }
                    )
                    Tab.TUTOR -> TutorScreen()
                    Tab.PRACTICE -> PracticeScreen()
                    Tab.NOTES -> NotesScreen()
                    Tab.PROFILE -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp),
        content = content
    )
}

@Composable
private fun HomeScreen(onTutor: () -> Unit, onPractice: () -> Unit, onNotes: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).background(
                        Brush.linearGradient(listOf(Purple, Color(0xFF5832A8))),
                        RoundedCornerShape(14.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.AutoAwesome, null, tint = White) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("StudyMate AI", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                    Text("Your learning companion", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.NotificationsNone, null, tint = Lavender)
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.linearGradient(listOf(Color(0xFF38245F), Color(0xFF211932))), RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Text("LEARN SMARTER", color = Lavender, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("Small steps.\nBig results.", color = White, fontSize = 29.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                Spacer(Modifier.height(8.dp))
                Text("Ask questions, practise and make every study session count.", color = Color(0xFFD5CBE7), fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onTutor, colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(14.dp)) {
                    Text("Ask AI Tutor"); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
        item { SectionTitle("Your study space", "Choose what you want to do") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard("AI Tutor", "Understand concepts", Icons.Default.AutoAwesome, Modifier.weight(1f), onTutor)
                FeatureCard("Practice", "Test your knowledge", Icons.Default.Quiz, Modifier.weight(1f), onPractice)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard("Smart Notes", "Revise key ideas", Icons.Default.Description, Modifier.weight(1f), onNotes)
                FeatureCard("Study goals", "Build consistency", Icons.Default.Flag, Modifier.weight(1f)) {}
            }
        }
        item { SectionTitle("Popular subjects", "Start with a subject") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SubjectRow("Mathematics", "Algebra • Calculus • Geometry", Icons.Default.Calculate)
                SubjectRow("Physics", "Mechanics • Electricity • Optics", Icons.Default.Bolt)
                SubjectRow("Chemistry", "Physical • Organic • Inorganic", Icons.Default.Science)
                SubjectRow("Biology", "Botany • Zoology • Human biology", Icons.Default.Eco)
            }
        }
        item {
            Text("For Classes 9–12, JEE, NEET and CET preparation", color = Muted, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.fillMaxWidth().background(Surface, RoundedCornerShape(18.dp))
            .clickable { onClick() }.padding(15.dp)
    ) {
        Icon(icon, null, tint = Lavender, modifier = Modifier.size(25.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SubjectRow(name: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(15.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).background(Surface2, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Lavender)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(name, color = White, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun TutorScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Hi! I'm your StudyMate AI tutor. Ask me a question about any school subject or entrance-exam topic. The live AI connection will be added in the next development step.") }
    PageColumn {
        Text("AI Tutor", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Ask. Understand. Improve.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Column(Modifier.weight(1f).fillMaxWidth().background(Surface, RoundedCornerShape(20.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Lavender)
                Spacer(Modifier.width(8.dp))
                Text("StudyMate Assistant", color = Lavender, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(18.dp))
            Text(answer, color = White, fontSize = 14.sp, lineHeight = 22.sp)
            Spacer(Modifier.height(12.dp))
            Text("Tip: Include your class, subject and chapter for a more focused explanation.", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().background(Surface2, RoundedCornerShape(16.dp)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = question, onValueChange = { question = it },
                modifier = Modifier.weight(1f).padding(10.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
                decorationBox = { inner ->
                    if (question.isEmpty()) Text("Ask your study question...", color = Muted, fontSize = 14.sp)
                    inner()
                }
            )
            IconButton(onClick = {
                if (question.isNotBlank()) {
                    answer = "Your question: \"$question\"\n\nThe AI service is not connected yet. This starter app has the working interface; we'll securely connect the AI backend next."
                    question = ""
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Lavender)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("AI answers can make mistakes. Verify important facts with trusted textbooks.", color = Muted, fontSize = 10.sp)
    }
}

private data class QuizQuestion(val question: String, val options: List<String>, val correct: Int, val explanation: String)

@Composable
private fun PracticeScreen() {
    val questions = listOf(
        QuizQuestion("Which of these is a prime number?", listOf("21", "29", "33", "39"), 1, "29 has exactly two positive factors: 1 and 29."),
        QuizQuestion("What is the SI unit of electric current?", listOf("Volt", "Ohm", "Ampere", "Watt"), 2, "Electric current is measured in amperes (A)."),
        QuizQuestion("Which molecule carries genetic information in most organisms?", listOf("DNA", "Glucose", "Water", "Starch"), 0, "DNA stores hereditary information in most organisms.")
    )
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    val q = questions[index]
    PageColumn {
        Text("Quick Practice", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("A small sample quiz to get started", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        Text("QUESTION ${index + 1} OF ${questions.size}", color = Lavender, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(q.question, color = White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(20.dp))
        q.options.forEachIndexed { i, option ->
            val isSelected = selected == i
            val bg = if (checked && i == q.correct) Color(0xFF214B3B) else if (isSelected) Color(0xFF39285B) else Surface
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).background(bg, RoundedCornerShape(14.dp))
                    .clickable(enabled = !checked) { selected = i }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${'A' + i}.", color = Lavender, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(12.dp))
                Text(option, color = White)
            }
        }
        if (checked) {
            Text(if (selected == q.correct) "Correct! 🎉" else "Not quite. The correct answer is ${q.options[q.correct]}.",
                color = Lavender, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(q.explanation, color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = {
                if (!checked && selected >= 0) checked = true
                else if (index < questions.lastIndex) { index++; selected = -1; checked = false }
                else { index = 0; selected = -1; checked = false }
            },
            enabled = checked || selected >= 0,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple),
            shape = RoundedCornerShape(14.dp)
        ) { Text(if (checked && index == questions.lastIndex) "Restart quiz" else if (checked) "Next question" else "Check answer") }
    }
}

@Composable
private fun NotesScreen() {
    val notes = listOf(
        "Mathematics" to "Revise formulas, definitions and solved examples. Practise a few problems after each topic.",
        "Physics" to "Write down the key laws, SI units, graphs and assumptions. Understand the concept before memorising formulas.",
        "Chemistry" to "Organise reactions, conditions, named reactions and important exceptions topic by topic.",
        "Biology" to "Use labelled diagrams, definitions and comparison tables. Revise terminology regularly."
    )
    PageColumn {
        Text("Smart Notes", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your starter revision library", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        notes.forEach { (subject, body) ->
            Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Surface, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text(subject, color = Lavender, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(body, color = White, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
        Text("These are sample notes. Personal note saving and AI-generated summaries will be added later.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ProfileScreen() {
    PageColumn {
        Text("Your Profile", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Make StudyMate work for your goals", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(74.dp).background(Surface2, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.School, null, tint = Lavender, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("Welcome, learner!", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Your learning journey starts here.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        listOf("Class / grade", "Board or curriculum", "Exam goal", "Preferred subjects").forEach { label ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Surface, RoundedCornerShape(13.dp)).padding(16.dp)) {
                Text(label, color = White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Profile setup and cloud sync will be implemented in a later version.", color = Muted, fontSize = 11.sp)
    }
}
